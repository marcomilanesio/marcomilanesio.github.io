class MyCustomError(RuntimeError)
    pass



def myfunction(x, y):
    try:
        f(x,y)
    except Exception as e:
        print(e.__name__)
        return 'No!'
    finally:
        print('done nonetheless')


def f(x, y):
    if y == 0:
        raise RuntimeError
    return x / y


if __name__ == "__main__":
    import sys
    a = sys.argv[1]  # string
    b = sys.argv[2]
    try:
        f(int(a),int(b))
    except RuntimeError:
        print('yikes')



