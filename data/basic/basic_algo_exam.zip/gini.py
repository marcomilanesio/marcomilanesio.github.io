import numpy as np

def gini_impurity(y):
    """
    Calculate Gini impurity for labels y.
    param y: np.array / list 
    return: float
    """
    classes, counts = np.unique(y, return_counts=True)
    impurity = 1 - np.sum((counts / counts.sum()) ** 2)
    return impurity

def split_dataset(X, y, feature_index, threshold):
    """
    Split dataset into left/right parts based on threshold.
    param X: features
    param y: labels
    param feature_index: int
    param threshold: int/float
    return tuple (Xleft, yleft, Xright, yright)
    """
    pass

def best_split(X, y):
    """
    Find the best split for dataset.
    param X: features
    param y: labels
    return tuple
    """
    n_samples, n_features = X.shape
    if n_samples <= 1:
        return None, None
    pass
    # OPTIONAL 2: implement optimization strategy

