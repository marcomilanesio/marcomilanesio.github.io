import numpy as np
from gini import best_split
import matplotlib.pyplot as plt

np.random.seed(0)

def create_super_simple_dataset():
    X = np.array([1,2,3,6,7,8]).reshape(-1,1)
    y = np.array([0,0,0,1,1,1])
    return X, y

def create_simple_dataset():
    X = np.array([[2, 3],
              [1, 1],
              [3, 2],
              [6, 5],
              [7, 8],
              [8, 6]])
    y = np.array([0, 0, 0, 1, 1, 1])
    return X, y

def create_random_dataset():
    X = np.random.randint(10, size=(10,10))
    y = np.random.randint(2, size=(10,))
    return X, y

if __name__ == "__main__":
    # do stuff here
    

    # OPTIONAL1: plot the history of the gini factor
