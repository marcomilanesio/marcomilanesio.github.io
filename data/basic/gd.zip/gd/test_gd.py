import unittest
from gd import gradient, gradient_descent

class TestGD(unittest.TestCase):
    # WARNING: UNIVARIATE ONLY!!!!!!!!!!!!
    def test_gradient_quadratic(self):
        f = lambda p: p[0]**2
        for val in [-3.0, -1.0, 0.0, 2.0]:
            approx = gradient(f, [val])[0]
            true_grad = 2 * val
            self.assertAlmostEqual(approx, true_grad, delta=1e-5)
    
    def test_gradient_multivariate(self):
        f = lambda p: p[0]**2 + p[1]**2    # grad(x^2 + y^2) = (2x, 2y)
        approx_grad = gradient(f, x=[3, -4])
        true_grad = [6, -8]
        for a, b in zip(approx_grad, true_grad):
            self.assertAlmostEqual(a,b, places=2)

    def test_descent_quadratic(self):
        # f(x) = (x - 3) ^ 2
        f = lambda p: (p[0] - 3) ** 2
        sol, _ = gradient_descent(f, init_x=[0], lr=0.1, n_iterations=50)
        self.assertAlmostEqual(sol[0], 3.0, places=2)
    
    def test_descent_multivariate(self):
        pass


#if __name__ == "__main__":
#    unittest.main()




