from gd import gradient_descent
import math
import matplotlib.pyplot as plt


def f(p):
    # p is list, len(p) == 2
    # (x - 3)^2 + (y + 2)^2
    #x, y = p
    #return (x - 3)**2 + (y+2)**2
    x, y, z = p
    return (-math.cos(x) - math.cos(y) - math.cos(z) + 0.1 * (x**2 + y**2 +z**2))


if __name__ == "__main__":
    solution, history = gradient_descent(f, init_x=[2.0,-1.0,3.0], lr=0.9, n_iterations=100)
    print(f"Solution: {solution}")
    print(f"Final solution value: {f(solution)}")

    loss_values = [f(p) for p in history]
    plt.plot([p[0] for p in history], label='x')
    plt.plot([p[1] for p in history], label='y')
    plt.plot([p[2] for p in history], label='z')
    plt.xlabel = "Iterations"
    plt.ylabel = "param value"
    plt.legend()
    plt.grid(True)
    plt.show()
    




