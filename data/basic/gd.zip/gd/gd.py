def gradient(func, x, h=1e-6): # 10^(-6)
    grad = []
    for i in range(len(x)):
        x_h1 = x[:]
        x_h2 = x[:]
        x_h1[i] += h
        x_h2[i] -= h
        g = ( func(x_h1) - func(x_h2) ) / (2 * h)
        grad.append(g)
    return grad


def gradient_descent(func, init_x, lr=0.1, n_iterations=30):
    """
    x = init_x
    for each iteration:
        compute the gradient on x
        x = for each "component" of x --> x - (lr * gradient)
        history.append(x)

    return x, history
    """
    x = init_x[:]
    history = [x[:]]
    for i in range(n_iterations):
        grad = gradient(func, x)
        x = [xi - lr * gi for xi, gi in zip(x, grad)]
        history.append(x[:])
    return x, history










